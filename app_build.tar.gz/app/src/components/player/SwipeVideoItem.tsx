// ===== Swipe Video Item (single video card for TikTok-style player) =====
import React, { useRef, useEffect, useState, useCallback, memo, useMemo } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Dimensions,
  ActivityIndicator, StatusBar, Share, Platform,
} from 'react-native';
import Video, { VideoRef, ResizeMode, OnLoadData, OnProgressData } from 'react-native-video';
import { getMediaUrl } from '../../services/api';
import { formatDuration } from '../../utils/format';
import { COLORS } from '../../utils/constants';

const { width: W, height: H } = Dimensions.get('window');

export interface SwipeEpisodeData {
  id: number;
  drama_id: number;
  episode_number: number;
  title: string;
  video_path: string;
  duration: number;
  is_free: number;
  points_cost: number;
  drama_title?: string;
  drama_genre?: string;
  drama_status?: string;
  episode_count?: number;
}

interface Props {
  data: SwipeEpisodeData;
  isActive: boolean;
  onToggleLike: (dramaId: number) => void;
  onToggleFavorite: (dramaId: number) => void;
  isLiked: boolean;
  isFavorited: boolean;
  onVideoEnd: () => void;
  onProgressUpdate: (progress: number, duration: number) => void;
  index: number;
  totalEpisodes: number;
}

const SwipeVideoItem: React.FC<Props> = memo(({
  data,
  isActive,
  onToggleLike,
  onToggleFavorite,
  isLiked,
  isFavorited,
  onVideoEnd,
  onProgressUpdate,
  index,
  totalEpisodes,
}) => {
  const videoRef = useRef<VideoRef>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [hasError, setHasError] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekPosition, setSeekPosition] = useState(0);

  const controlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Memoize video URI to avoid unnecessary re-renders
  const videoUri = useMemo(() => data.video_path ? getMediaUrl(data.video_path) : '', [data.video_path]);
  const progressPercent = duration > 0 ? ((isSeeking ? seekPosition : currentTime) / duration) * 100 : 0;
  const displayTime = isSeeking ? seekPosition : currentTime;

  // Auto-hide controls
  useEffect(() => {
    if (isPlaying && !isLoading && !hasError) {
      controlsTimer.current = setTimeout(() => setControlsVisible(false), 4000);
    }
    return () => { if (controlsTimer.current) clearTimeout(controlsTimer.current); };
  }, [isPlaying, isLoading, hasError]);

  // Play/pause based on isActive
  useEffect(() => {
    if (isActive) {
      const t = setTimeout(() => {
        setIsPlaying(true);
      }, 150);
      return () => clearTimeout(t);
    } else {
      setIsPlaying(false);
    }
  }, [isActive]);

  const handleLoad = useCallback((d: OnLoadData) => {
    setIsLoading(false);
    setHasError(false);
    setDuration(d.duration);
  }, []);

  // Throttle progress updates to avoid excessive re-renders
  const lastProgressRef = useRef(0);
  const handleProgress = useCallback((d: OnProgressData) => {
    const now = Date.now();
    // Only update state every 1 second
    if (now - lastProgressRef.current < 1000) return;
    lastProgressRef.current = now;
    if (!isSeeking) setCurrentTime(d.currentTime);
    const dur = d.playableDuration || duration;
    if (dur > 0) {
      setDuration(dur);
    }
  }, [isSeeking, duration]);

  const handleError = useCallback(() => {
    setIsLoading(false);
    setHasError(true);
  }, []);

  const togglePlayPause = useCallback(() => {
    setControlsVisible(true);
    setIsPlaying(prev => !prev);
  }, []);

  const handleSeekStart = useCallback((pos: number) => {
    setSeekPosition(pos);
    setIsSeeking(true);
    setControlsVisible(true);
  }, []);

  const handleSeekEnd = useCallback((pos: number) => {
    setSeekPosition(pos);
    setCurrentTime(pos);
    setIsSeeking(false);
  }, []);

  const statusBarPadTop = Platform.OS === 'android' ? (StatusBar.currentHeight || 24) : 50;

  const handleShare = useCallback(async () => {
    try {
      await Share.share({
        title: data.drama_title || 'DramaFlix',
        message: `Watch "${data.drama_title || 'a drama'}" Ep.${data.episode_number} on DramaFlix! http://43.159.62.11`,
      });
    } catch (_) {}
  }, [data.drama_title, data.episode_number]);

  const retryPlay = useCallback(() => {
    setHasError(false);
    setIsLoading(true);
    setIsPlaying(true);
  }, []);

  const progressWidth = Math.max(0, W - 32);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000" translucent={false} />

      {/* Video */}
      <View style={styles.videoWrapper}>
        {videoUri ? (
          <Video
            ref={videoRef}
            source={{ uri: videoUri }}
            style={styles.video}
            resizeMode={ResizeMode.CONTAIN}
            onLoad={handleLoad}
            onProgress={handleProgress}
            onEnd={onVideoEnd}
            onError={handleError}
            useNativeControls={false}
            repeat={false}
            paused={!isActive || !isPlaying}
            posterResizeMode={ResizeMode.CONTAIN}
            allowsExternalPlayback={false}
            playInBackground={false}
            progressUpdateInterval={1000}
            bufferConfig={{
              minBufferMs: 15000,
              maxBufferMs: 50000,
              bufferForPlaybackMs: 2500,
              bufferForPlaybackAfterRebufferMs: 5000,
            }}
            // Use native player for smoother playback
            controls={false}
            posterResizeMode={ResizeMode.CONTAIN}
          />
        ) : (
          <View style={styles.centerOverlay}>
            <Text style={styles.errorText}>No video</Text>
          </View>
        )}
      </View>

      {/* Loading */}
      {isLoading && !hasError && isActive && (
        <View style={styles.centerOverlay}>
          <ActivityIndicator size="large" color={COLORS.primaryLight} />
        </View>
      )}

      {/* Error */}
      {hasError && !isLoading && (
        <View style={styles.centerOverlay}>
          <Text style={styles.errorText}>Playback Error</Text>
          <TouchableOpacity style={styles.retryBtn} onPress={retryPlay} activeOpacity={0.7}>
            <Text style={styles.retryText}>Retry</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Tap to play/pause */}
      {isActive && !isLoading && !hasError && (
        <TouchableOpacity style={StyleSheet.absoluteFill} activeOpacity={1} onPress={togglePlayPause} />
      )}

      {/* ===== Top bar ===== */}
      {controlsVisible && !hasError && (
        <View style={styles.topFade}>
          <View style={[styles.topBar, { paddingTop: statusBarPadTop }]}>
            <View style={styles.epBadge}>
              <Text style={styles.epBadgeText}>EP.{data.episode_number}</Text>
            </View>
            <View style={styles.titleBox}>
              <Text style={styles.dramaTitle} numberOfLines={1}>{data.drama_title || ''}</Text>
              {data.title ? (
                <Text style={styles.epTitle} numberOfLines={1}>{data.title}</Text>
              ) : null}
            </View>
            <View style={styles.topRight}>
              {data.is_free === 0 && data.points_cost > 0 && (
                <View style={styles.lockBadge}>
                  <Text style={styles.lockText}>{data.points_cost} pts</Text>
                </View>
              )}
            </View>
          </View>
        </View>
      )}

      {/* Play/Pause center */}
      {!isLoading && !isPlaying && !hasError && isActive && (
        <TouchableOpacity style={styles.playBtnCenter} onPress={togglePlayPause} activeOpacity={0.8}>
          <Text style={styles.playIconCenter}>{'\u25B6'}</Text>
        </TouchableOpacity>
      )}

      {/* ===== Right side actions ===== */}
      {controlsVisible && !hasError && (
        <View style={styles.rightActions}>
          <View style={styles.dramaCover}>
            <Text style={styles.dramaCoverEmoji}>{'\u{1F3AC}'}</Text>
          </View>
          <Text style={styles.dramaCoverLabel}>{data.episode_count || totalEpisodes} eps</Text>

          <View style={styles.actionSpacing} />
          <ActionIcon icon={isLiked ? '\u2764' : '\u2661'} label="Like" active={isLiked} onPress={() => onToggleLike(data.drama_id)} />
          <ActionIcon icon={isFavorited ? '\u2605' : '\u2606'} label="Collect" active={isFavorited} onPress={() => onToggleFavorite(data.drama_id)} />
          <ActionIcon icon={'\u21AA'} label="Share" active={false} onPress={handleShare} />
        </View>
      )}

      {/* ===== Bottom bar ===== */}
      {controlsVisible && !hasError && (
        <View style={styles.bottomBar}>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: progressPercent + '%' }]} />
            <View style={[styles.progressThumb, { left: progressPercent + '%' }]} />
            <TouchableOpacity
              style={[styles.progressTouchArea, { width: progressWidth }]}
              onMove={(e: any) => {
                try {
                  const x = e.nativeEvent.locationX;
                  const pos = Math.max(0, Math.min(x / progressWidth, 1)) * duration;
                  handleSeekStart(pos);
                } catch (_) {}
              }}
              onPress={(e: any) => {
                try {
                  const x = e.nativeEvent.locationX;
                  const pos = Math.max(0, Math.min(x / progressWidth, 1)) * duration;
                  handleSeekEnd(pos);
                } catch (_) {}
              }}
              activeOpacity={1}
            />
          </View>
          <View style={styles.timeRow}>
            <Text style={styles.timeText}>{formatDuration(displayTime)}</Text>
            <Text style={styles.timeText}>{formatDuration(duration)}</Text>
          </View>
          <View style={styles.epIndicator}>
            <Text style={styles.epIndicatorText}>
              {data.drama_title} {'\u00B7'} EP.{data.episode_number}/{data.episode_count || totalEpisodes}
            </Text>
          </View>
        </View>
      )}
    </View>
  );
});

// ===== Small Action Button =====
const ActionIcon: React.FC<{ icon: string; label: string; active: boolean; onPress: () => void }> = memo(
  ({ icon, label, active, onPress }) => (
    <TouchableOpacity style={styles.actionBtn} onPress={onPress} activeOpacity={0.7}>
      <Text style={[styles.actionIcon, active ? styles.actionIconActive : null]}>{icon}</Text>
      <Text style={[styles.actionLabel, active ? styles.actionLabelActive : null]}>{label}</Text>
    </TouchableOpacity>
  )
);

const styles = StyleSheet.create({
  container: {
    width: W,
    height: H,
    backgroundColor: '#000',
  },
  videoWrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: W,
    height: H,
    overflow: 'hidden',
  },
  video: {
    width: W,
    height: H,
  },
  centerOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Top
  topFade: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 10,
    paddingHorizontal: 12,
  },
  epBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(103,80,164,0.85)',
  },
  epBadgeText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '700',
  },
  titleBox: {
    flex: 1,
    marginLeft: 10,
  },
  dramaTitle: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
  },
  epTitle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    marginTop: 2,
  },
  topRight: {
    alignItems: 'flex-end',
  },
  lockBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    backgroundColor: 'rgba(255,184,0,0.85)',
  },
  lockText: {
    color: '#000',
    fontSize: 11,
    fontWeight: '700',
  },

  // Play center
  playBtnCenter: {
    position: 'absolute',
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  playIconCenter: {
    color: '#FFF',
    fontSize: 28,
    marginLeft: 4,
  },

  // Error
  errorText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 16,
    marginBottom: 16,
  },
  retryBtn: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  retryText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '600',
  },

  // Right actions
  rightActions: {
    position: 'absolute',
    right: 10,
    bottom: H * 0.22,
    alignItems: 'center',
  },
  dramaCover: {
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  dramaCoverEmoji: {
    fontSize: 20,
  },
  dramaCoverLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 10,
    marginBottom: 16,
  },
  actionSpacing: {
    height: 10,
  },
  actionBtn: {
    alignItems: 'center',
    marginBottom: 20,
  },
  actionIcon: {
    fontSize: 26,
    color: '#FFF',
  },
  actionIconActive: {
    color: '#FF4757',
  },
  actionLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 10,
    fontWeight: '500',
    marginTop: 3,
  },
  actionLabelActive: {
    color: '#FF4757',
  },

  // Bottom
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.45)',
    paddingTop: 12,
    paddingBottom: Platform.OS === 'android' ? 8 : 20,
  },
  progressTrack: {
    height: 24,
    justifyContent: 'center',
    position: 'relative',
    marginLeft: 16,
    marginRight: 16,
  },
  progressFill: {
    height: 3,
    borderRadius: 1.5,
    backgroundColor: COLORS.primaryLight,
    position: 'absolute',
    left: 0,
    top: 10.5,
  },
  progressThumb: {
    position: 'absolute',
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#FFF',
    marginLeft: -7,
    top: 5,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 2,
    shadowOffset: { width: 0, height: 1 },
  },
  progressTouchArea: {
    height: 24,
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 16,
    paddingRight: 16,
    marginTop: -2,
  },
  timeText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 11,
  },
  epIndicator: {
    marginTop: 6,
    alignItems: 'center',
  },
  epIndicatorText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 11,
  },
});

export default SwipeVideoItem;
