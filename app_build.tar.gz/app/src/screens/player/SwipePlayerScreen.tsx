// ===== Swipe Player Screen (TikTok-style vertical scrolling) =====
// Swipe up/down to switch episodes. Automatically loads next drama when current finishes.
import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Dimensions,
  ActivityIndicator, StatusBar, Platform, FlatList,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useDramaStore, usePlayerStore, useAuthStore } from '../../stores';
import { dramaService } from '../../services/drama.service';
import { interactionService } from '../../services/interaction.service';
import { getMediaUrl } from '../../services/api';
import { COLORS } from '../../utils/constants';
import SwipeVideoItem, { type SwipeEpisodeData } from '../../components/player/SwipeVideoItem';

const { height: SCREEN_H } = Dimensions.get('window');

type RouteParams = {
  dramaId: number;
  startEpisodeId?: number;
};

// Build SwipeEpisodeData from Drama + Episode
const toSwipeData = (ep: any, drama: any): SwipeEpisodeData => ({
  id: ep.id,
  drama_id: ep.drama_id || drama.id,
  episode_number: ep.episode_number,
  title: ep.title,
  video_path: ep.video_path,
  duration: ep.duration || 0,
  is_free: ep.is_free ?? 1,
  points_cost: ep.points_cost || 0,
  drama_title: drama.title,
  drama_genre: drama.genre,
  drama_status: drama.status,
  episode_count: drama.episode_count || drama.episodes?.length,
});

export const SwipePlayerScreen: React.FC = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const params = (route.params || {}) as RouteParams;
  const initialDramaId = params.dramaId;
  const startEpId = params.startEpisodeId;

  const flatListRef = useRef<FlatList>(null);
  const { isAuthenticated } = useAuthStore();
  const { setProgress, saveProgress, clearPlayer } = usePlayerStore();

  // All episodes to display (flattened across dramas)
  const [episodes, setEpisodes] = useState<SwipeEpisodeData[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);

  // Interaction states per drama
  const [likedDramas, setLikedDramas] = useState<Set<number>>(new Set());
  const [favoritedDramas, setFavoritedDramas] = useState<Set<number>>(new Set());

  // Track which drama IDs we've already loaded (to avoid duplicates when chaining)
  const loadedDramaIds = useRef<Set<number>>(new Set());
  // Track which next dramas to preload
  const dramaQueue = useRef<number[]>([]);

  // Auto save timer
  const saveTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  // Load initial drama and build episode list
  const loadInitialDrama = useCallback(async (dramaId: number, episodeId?: number) => {
    setIsLoading(true);
    setIsError(false);
    try {
      const drama = await dramaService.getDramaDetail(dramaId);
      if (!drama || !drama.episodes || drama.episodes.length === 0) {
        setIsError(true);
        setIsLoading(false);
        return;
      }

      loadedDramaIds.current.add(dramaId);

      const swipeEps = drama.episodes.map(ep => toSwipeData(ep, drama));

      // Find start index
      let startIdx = 0;
      if (episodeId) {
        const found = swipeEps.findIndex(e => e.id === episodeId);
        if (found >= 0) startIdx = found;
      }

      setEpisodes(swipeEps);
      setCurrentIndex(startIdx);

      // Pre-fetch more dramas for continuous swiping
      try {
        const res = await dramaService.getDramas({ page: 1, pageSize: 10 });
        dramaQueue.current = res.list
          .filter((d: any) => d.id !== dramaId)
          .map((d: any) => d.id);
      } catch (_) {}

      setIsLoading(false);

      // Check interaction states
      if (isAuthenticated) {
        interactionService.checkFavorite(dramaId, 'like').then(ok => {
          if (ok) setLikedDramas(prev => new Set([...prev, dramaId]));
        }).catch(() => {});
        interactionService.checkFavorite(dramaId, 'favorite').then(ok => {
          if (ok) setFavoritedDramas(prev => new Set([...prev, dramaId]));
        }).catch(() => {});
      }

      // Record view
      dramaService.recordView(dramaId).catch(() => {});
    } catch (err) {
      console.error('Failed to load drama:', err);
      setIsError(true);
      setIsLoading(false);
    }
  }, [isAuthenticated]);

  // Load next drama's episodes and append
  const loadNextDrama = useCallback(async () => {
    // Find next unloaded drama
    let nextDramaId: number | null = null;
    while (dramaQueue.current.length > 0) {
      const candidate = dramaQueue.current.shift()!;
      if (!loadedDramaIds.current.has(candidate)) {
        nextDramaId = candidate;
        break;
      }
    }
    if (!nextDramaId) return;

    try {
      const drama = await dramaService.getDramaDetail(nextDramaId);
      if (!drama || !drama.episodes || drama.episodes.length === 0) return;

      loadedDramaIds.current.add(nextDramaId);

      const newEps = drama.episodes.map(ep => toSwipeData(ep, drama));

      setEpisodes(prev => [...prev, ...newEps]);

      // Check interaction states for new drama
      if (isAuthenticated) {
        interactionService.checkFavorite(nextDramaId, 'like').then(ok => {
          if (ok) setLikedDramas(prev => new Set([...prev, nextDramaId]));
        }).catch(() => {});
        interactionService.checkFavorite(nextDramaId, 'favorite').then(ok => {
          if (ok) setFavoritedDramas(prev => new Set([...prev, nextDramaId]));
        }).catch(() => {});
      }

      // Load more drama queue
      if (dramaQueue.current.length < 3) {
        const res = await dramaService.getDramas({ page: 1, pageSize: 10 });
        dramaQueue.current = res.list
          .filter((d: any) => !loadedDramaIds.current.has(d.id))
          .map((d: any) => d.id);
      }
    } catch (err) {
      console.error('Failed to load next drama:', err);
    }
  }, [isAuthenticated]);

  // Initial load
  useEffect(() => {
    loadInitialDrama(initialDramaId, startEpId);
  }, [initialDramaId, startEpId]);

  // Auto save progress periodically
  useEffect(() => {
    saveTimer.current = setInterval(() => {
      saveProgress();
    }, 10000);
    return () => {
      if (saveTimer.current) clearInterval(saveTimer.current);
      saveProgress();
      clearPlayer();
    };
  }, [saveProgress, clearPlayer]);

  // Preload next drama when nearing the end of current episodes
  useEffect(() => {
    if (episodes.length > 0 && currentIndex >= episodes.length - 2) {
      loadNextDrama();
    }
  }, [currentIndex, episodes.length, loadNextDrama]);

  // Update current episode in playerStore
  const currentEpisode = episodes[currentIndex] || null;

  // Called when current video ends - auto advance to next
  const handleVideoEnd = useCallback(() => {
    saveProgress();
    if (currentIndex < episodes.length - 1) {
      // Go to next episode
      setTimeout(() => {
        try {
          flatListRef.current?.scrollToIndex({ index: currentIndex + 1, animated: true });
        } catch (_) {}
      }, 300);
    }
    // If it's the last episode, loadNextDrama will be triggered by the effect above
  }, [currentIndex, episodes.length, saveProgress]);

  // Handle progress update from active video
  const handleProgress = useCallback((progress: number, duration: number) => {
    if (currentEpisode) {
      const { setEpisode } = usePlayerStore.getState();
      setEpisode(
        {
          id: currentEpisode.id,
          drama_id: currentEpisode.drama_id,
          episode_number: currentEpisode.episode_number,
          title: currentEpisode.title,
          video_path: currentEpisode.video_path,
          duration: currentEpisode.duration,
          is_free: currentEpisode.is_free,
          points_cost: currentEpisode.points_cost,
          created_at: '',
        },
        currentEpisode.drama_id,
      );
      setProgress(progress, duration);
    }
  }, [currentEpisode, setProgress]);

  // Viewable items changed
  const onViewableItemsChanged = useRef(({ viewableItems }: any) => {
    if (viewableItems && viewableItems.length > 0) {
      const idx = viewableItems[0].index;
      if (typeof idx === 'number' && idx !== currentIndex) {
        setCurrentIndex(idx);
      }
    }
  }).current;

  const viewabilityConfig = useRef({ itemVisiblePercentThreshold: 80 }).current;

  // Toggle like
  const toggleLike = useCallback(async (dramaId: number) => {
    if (!isAuthenticated || !dramaId) return;
    try {
      const isLiked = likedDramas.has(dramaId);
      if (isLiked) {
        await interactionService.removeFavorite(dramaId, 'like');
        setLikedDramas(prev => { const s = new Set(prev); s.delete(dramaId); return s; });
      } else {
        await interactionService.addFavorite(dramaId, 'like');
        setLikedDramas(prev => new Set([...prev, dramaId]));
      }
    } catch (_) {}
  }, [isAuthenticated, likedDramas]);

  // Toggle favorite
  const toggleFavorite = useCallback(async (dramaId: number) => {
    if (!isAuthenticated || !dramaId) return;
    try {
      const isFav = favoritedDramas.has(dramaId);
      if (isFav) {
        await interactionService.removeFavorite(dramaId, 'favorite');
        setFavoritedDramas(prev => { const s = new Set(prev); s.delete(dramaId); return s; });
      } else {
        await interactionService.addFavorite(dramaId, 'favorite');
        setFavoritedDramas(prev => new Set([...prev, dramaId]));
      }
    } catch (_) {}
  }, [isAuthenticated, favoritedDramas]);

  // Go back
  const goBack = useCallback(() => {
    saveProgress();
    clearPlayer();
    try { navigation.goBack(); } catch (_) {}
  }, [navigation, saveProgress, clearPlayer]);

  // Get current episode's drama_id for interaction display
  const currentDramaId = currentEpisode?.drama_id || initialDramaId;

  const getItemLayout = useCallback((_data: any, index: number) => ({
    length: SCREEN_H,
    offset: SCREEN_H * index,
    index,
  }), []);

  const renderItem = useCallback(({ item, index }: { item: SwipeEpisodeData; index: number }) => (
    <SwipeVideoItem
      data={item}
      isActive={index === currentIndex}
      onToggleLike={toggleLike}
      onToggleFavorite={toggleFavorite}
      isLiked={likedDramas.has(item.drama_id)}
      isFavorited={favoritedDramas.has(item.drama_id)}
      onVideoEnd={index === currentIndex ? handleVideoEnd : () => {}}
      onProgressUpdate={() => {}}
      index={index}
      totalEpisodes={episodes.length}
    />
  ), [currentIndex, likedDramas, favoritedDramas, handleVideoEnd, toggleLike, toggleFavorite, episodes.length]);

  const keyExtractor = useCallback((item: SwipeEpisodeData) => `ep-${item.id}`, []);

  // Loading state
  if (isLoading && episodes.length === 0) {
    return (
      <View style={styles.loadingContainer}>
        <StatusBar barStyle="light-content" backgroundColor="#000" />
        <ActivityIndicator size="large" color={COLORS.primaryLight} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  // Error state
  if (isError) {
    return (
      <View style={styles.loadingContainer}>
        <StatusBar barStyle="light-content" backgroundColor="#000" />
        <Text style={styles.errorText}>Failed to load</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={() => loadInitialDrama(initialDramaId)} activeOpacity={0.7}>
          <Text style={styles.retryText}>Retry</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.retryBtn, styles.retryBtnMargin]} onPress={goBack} activeOpacity={0.7}>
          <Text style={styles.retryText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000" />

      <FlatList
        ref={flatListRef}
        data={episodes}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        getItemLayout={getItemLayout}
        snapToInterval={SCREEN_H}
        snapToAlignment="start"
        decelerationRate="fast"
        vertical
        showsVerticalScrollIndicator={false}
        viewabilityConfig={viewabilityConfig}
        onViewableItemsChanged={onViewableItemsChanged}
        windowSize={2}
        maxToRenderPerBatch={1}
        initialNumToRender={1}
        removeClippedSubviews={Platform.OS === 'android'}
        onEndReached={() => {
          // Load more dramas when nearing the end
          if (episodes.length - currentIndex <= 3) {
            loadNextDrama();
          }
        }}
        onEndReachedThreshold={0.5}
        ListFooterComponent={
          <View style={styles.footerLoading}>
            <ActivityIndicator size="small" color="rgba(255,255,255,0.5)" />
          </View>
        }
      />

      {/* Top-left back button - always visible */}
      <TouchableOpacity style={styles.backBtn} onPress={goBack} activeOpacity={0.7}>
        <Text style={styles.backIcon}>{'\u276E'}</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 14,
    marginTop: 12,
  },
  errorText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 16,
    marginBottom: 16,
  },
  retryBtn: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  retryBtnMargin: {
    marginTop: 10,
  },
  retryText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '600',
  },
  backBtn: {
    position: 'absolute',
    top: Platform.OS === 'android' ? (StatusBar.currentHeight || 24) + 4 : 54,
    left: 12,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 100,
  },
  backIcon: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '600',
  },
  footerLoading: {
    height: SCREEN_H,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
